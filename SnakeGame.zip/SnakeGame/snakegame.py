'''
This is a simple, text-based Snake game designed to run in the terminal. 
In this game, the player controls a snake using the "W", "A", "S", and "D" keys to 
move up, left, down, and right, respectively.The goal is to guide the snake to eat food, 
represented by the character "@". Each time the snake eats food, it grows longer.
The snake's body is represented by "S" characters. The game ends if the snake hits 
the wall or its own body.Food appears in random positions on the screen each time it's eaten,
making each game unique.
*-----------------*
Game Setup: Constants define screen size, snake, and food characters. Directions are mapped as constants 
for easy input processing.

SnakeGame Class: Handles initializing the game, generating food, updating the snake's position, 
checking collisions, and handling user inputs.

Main Game Loop: Continuously updates the game state based on user input until the game ends.
'''

import random 

# Game constants
BWIDTH= 30 #Width of the game screen
BHEIGHT= 15 # Height of the game screen
S_CHAR= "S" # Character representing the snake's body
FOOD_CHAR = "@" # Character representing the food
EMPTY= "-" # Character representing empty spaces on the screen

# Directions for snake movement and name the variables as it supposed to work 
UP = "UP"
DOWN = "DOWN"
LEFT = "LEFT"
RIGHT = "RIGHT"



# Snake game class
class SnakeGame:
    def __init__(self):
        # Initialize the game state and variables
        self.snake = [(BHEIGHT// 2, BWIDTH// 2)]  # Start the snake at the center of the screen
        self.food = None  # No food at the beginning
        self.direction = RIGHT  # Initial direction is to the right
        self.score = 0  # Initial score is 0
        self.game_over = False  # Game is active until the snake hits a wall or itself
        self.CreateFood()  # Generate the first food item

    def CreateFood(self):
        """Place food at a random location on the screen, avoiding the snake's current position"""
        FoodX= random.randint(0, BHEIGHT- 1)  # Randomly choose x-coordinate for food
        FoodY= random.randint(0, BWIDTH- 1)   # Randomly choose y-coordinate for food
        
        # Ensure food does not appear on the snake's body
        while (FoodX, FoodY) in self.snake:
            FoodX= random.randint(0, BHEIGHT- 1)
            FoodY= random.randint(0, BWIDTH- 1)

        self.food = (FoodX, FoodY)  # Set food position to chosen coordinates

    def move(self):
        """Move the snake in the current direction"""
        HeadX, HeadY = self.snake[0]  # Get the current head position of the snake
        
        # Update the head position based on the current direction
        if self.direction == UP: 
            HeadX -= 1 #the snake's head moves up by decreasing HeadX.
        elif self.direction == DOWN:
            HeadX += 1 #the snake's head moves down by increasing HeadX.
        elif self.direction == LEFT:
            HeadY -= 1 #the snake's head moves left by decreasing HeadY.
        elif self.direction == RIGHT:
            HeadY += 1 #the snake's head moves right by increasing HeadY.
        
        NewHead= (HeadX, HeadY)  # New position of the snake's head
        self.snake.insert(0, NewHead)  # Add new head position to the front of the snake's body

        # Check if the snake eats the food
        if NewHead== self.food:   # If the new head position is the same as the food's 
            self.score += 1  # Increase score
            self.CreateFood()  # Generate new food at a random position
        else:
            self.snake.pop()  # Remove tail if the snake didn't eat food (snake only grows if it eats food)

        # Check for collisions with walls or itself
        if not (0 <= HeadX < BHEIGHT and 0 <= HeadY < BWIDTH) or NewHead in self.snake[1:]:
            self.game_over = True  # Set game over if the snake hits the wall or itself


    def change_direction(self, new_direction): 
    #This method is used to change the direction of the snake based on the player’s input 
    #within SnakeGame class.or we can say Change direction if it's valid
    
        """Change the snake's direction, avoiding direct reversals"""
        # Update direction if it doesn't directly reverse the current direction
        if (self.direction == UP and new_direction != DOWN) or \
           (self.direction == DOWN and new_direction != UP) or \
           (self.direction == LEFT and new_direction != RIGHT) or \
           (self.direction == RIGHT and new_direction != LEFT):
            self.direction = new_direction
            

    def DrawBorder(self):
        """DrawBorder the game screen and display the score"""

        # Print the top border
        print("^" + "-" * BWIDTH + "^")

        # Print each row of the game board
        for row in range(BHEIGHT): # This line starts a for loop that iterates through each row 
        #of the game screen.
        
            line = "|" #This initializes a string line with the first character as "|", 
            #which represents the left border of the game screen.
            
            for col in range(BWIDTH): #This starts another for loop, which iterates over each
            #column in the current row.
            
                if (row, col) in self.snake: #This line checks if the current (row, col) position is part of
                #the snake's body.
                
                    line += S_CHAR # Display snake character if part of the snake
                    #If the condition is true (i.e., the current (row, col) position is part of 
                    #the snake), this line adds the snake character (S_CHAR, which is *) to the
                    #line string.
                    
                elif (row, col) == self.food: ##This line checks if the current (row, col) 
                #position is where the food is located.
                
                    line += FOOD_CHAR  # Display food character if food is at this position
                    #If the condition is true (i.e., the current (row, col) position is the food),
                    #this line adds the food character (FOOD_CHAR, which is O) to the line string.
                else:
                    line += EMPTY # Display empty character otherwise
                    #If the current position is empty (i.e., it is not part of the snake and not the food), 
                    #this line appends the empty character (.) to the line string
                    
            line += "|"
            #After the loop over all columns for the current row is finished, this line adds the right border (|) 
            #to the line string.
            
            print(line)#Each row of the game board is printed one by one in the loop.

        # Print the bottom border
        print("^" + "-" * BWIDTH+ "^")

        # Print the current score
        print("Score: {}".format(self.score))

    def play(self): #This defines the play method, which is responsible for running the main game loop
        """Run the game loop"""
        while not self.game_over:#This line starts the main game loop, which continues running as long as
        #the game is not over.
        
            self.DrawBorder()  # Display the game board
            #This method will render and print the current state of the game (the game board, the snake,
            #the food, and the score) to the console. It will be called at the start of each loop 
            #iteration to visually update the game screen.

            # Get user input for movement direction
            move = input("Enter your move (W for 'UP' A For 'LEFT' S FOR 'DOWN' D FOR 'RIGHT'): ").strip().upper()

            # Update direction based on user input
            if move == "W":
                self.change_direction(UP)
            elif move == "A":
                self.change_direction(LEFT)
            elif move == "S":
                self.change_direction(DOWN)
            elif move == "D":
                self.change_direction(RIGHT)

            # Move the snake in the current direction
            self.move()#This line calls the move method to update the snake’s position 
            #based on its current direction.

#If the snake eats food, it grows longer, and if it collides with a wall or itself, 
#the game ends (setting self.game_over = True).

        # Display game over message and final score
        
        print("\nGame Over! Thank you for playing") #If the game loop exits (because self.game_over became True),
        #this line prints the message "Game Over!" to the screen, notifying the player 
        #that the game has ended.
        
        print("Congratulations! Your final score is: {}".format(self.score))
        #This line prints the final score to the screen using the self.score value.


