'''
This is a simple, text-based Snake game designed to run in the terminal. 
In this game, the player controls a snake using the "W", "A", "S", and "D" keys to 
move up, left, down, and right, respectively.The goal is to guide the snake to eat food, 
represented by the character "@". Each time the snake eats food, it grows longer.
The snake's body is represented by "S" characters. The game ends if the snake hits 
the wall or its own body.Food appears in random positions on the screen each time it's eaten,
making each game unique.
*-----------------*
Game Setup: Constants define screen size, snake, and food characters. Directions are mapped as constants 
for easy input processing.

SnakeGame Class: Handles initializing the game, generating food, updating the snake's position, 
checking collisions, and handling user inputs.

Main Game Loop: Continuously updates the game state based on user input until the game ends.
'''

import random 
'''
The random module is imported to allow random placement of food on the screen. This module's 
functions are used to randomly generate the x and y coordinates for the food each time it appears.
'''

# Game constants
BWIDTH= 30 #Width of the game screen
BHEIGHT= 15 # Height of the game screen
S_CHAR= "S" # Character representing the snake's body
FOOD_CHAR = "@" # Character representing the food
EMPTY= "-" # Character representing empty spaces on the screen
'''
These constants define the game board's appearance:
•	BWIDTH and BHEIGHT set the width and height of the screen.
•	S_CHAR is the character used to represent the snake's body.
•	FOOD_CHAR represents the food.
•	EMPTY represents empty spaces on the screen.
'''
# Directions for snake movement and name the variables as it supposed to work 
UP = "UP"
DOWN = "DOWN"
LEFT = "LEFT"
RIGHT = "RIGHT"

'''
These constants represent the four possible directions the snake can move in. 
They help make direction-related code easier to understand and less error-prone.
'''

# Snake game class
class SnakeGame:
    def __init__(self):
        # Initialize the game state and variables
        self.snake = [(BHEIGHT// 2, BWIDTH// 2)]  # Start the snake at the center of the screen
        self.food = None  # No food at the beginning
        self.direction = RIGHT  # Initial direction is to the right
        self.score = 0  # Initial score is 0
        self.game_over = False  # Game is active until the snake hits a wall or itself
        self.CreateFood()  # Generate the first food item

#class SnakeGame:  # this class manages the entire game, including movements, position and 
#of food, score tracking and display of the game board. 

#def __init__(self):  #initializing the values. 

#self.snake = [(BHEIGHT// 2, BWIDTH// 2)]   # This places snake at the center of the board. 
#It initializes the snake’s body as a list with a single tuple. 

#self.food = None #it holds the position of food on the screen. Initially its None bit it will
#be set when food is generated. 

#self.direction = RIGHT  # The initial direction of the snake is set to RIGHT

#self.score = 0 # The score starts at 0 and increases each time the snake eats food

#self.game_over = False # A boolean flag indicating if the game has ended. Initially, it's set to False.

#self.CreateFood() #This method is called to place the first piece of food on the board.

    def CreateFood(self):
        """Place food at a random location on the screen, avoiding the snake's current position"""
        FoodX= random.randint(0, BHEIGHT- 1)  # Randomly choose x-coordinate for food
        FoodY= random.randint(0, BWIDTH- 1)   # Randomly choose y-coordinate for food
        
        # Ensure food does not appear on the snake's body
        while (FoodX, FoodY) in self.snake:
            FoodX= random.randint(0, BHEIGHT- 1)
            FoodY= random.randint(0, BWIDTH- 1)

        self.food = (FoodX, FoodY)  # Set food position to chosen coordinates

#def generate_food(self): #Place food at a random location. 

#FoodX = random.randint(0, BHEIGHT - 1) # These are random coordinates for the food's position. 
#The random.randint function generates a random integer between 0 and BHEIGHT - 1 for the 
#X position (vertical) and between 0 and BWIDTH - 1 for the Y position (horizontal).

#FoodY = random.randint(0, BWIDTH - 1)

#while (FoodX, FoodY) in self.snake:  # Ensure food is not on the snake. The while loop ensures
#that the food is not placed where the snake is currently located by checking 
#if the generated position (FoodX, FoodY) is already in self.snake.

#FoodX = random.randint(0, BHEIGHT - 1)
#FoodY = random.randint(0, BWIDTH - 1)

#self.food = (FoodX, FoodY)  # Once a valid position is found (not on the snake), 
#the food is placed at that position by assigning it to self.food.

#This method:
#Randomly generates coordinates (FoodX, FoodY) for the food.
#Checks if the food would spawn on the snake’s body; if so, it regenerates coordinates 
#until a free space is found.Sets self.food to these coordinates.

    def move(self):
        """Move the snake in the current direction"""
        HeadX, HeadY = self.snake[0]  # Get the current head position of the snake
        
        # Update the head position based on the current direction
        if self.direction == UP: 
            HeadX -= 1 #the snake's head moves up by decreasing HeadX.
        elif self.direction == DOWN:
            HeadX += 1 #the snake's head moves down by increasing HeadX.
        elif self.direction == LEFT:
            HeadY -= 1 #the snake's head moves left by decreasing HeadY.
        elif self.direction == RIGHT:
            HeadY += 1 #the snake's head moves right by increasing HeadY.
        
        NewHead= (HeadX, HeadY)  # New position of the snake's head
        self.snake.insert(0, NewHead)  # Add new head position to the front of the snake's body

        # Check if the snake eats the food
        if NewHead== self.food:   # If the new head position is the same as the food's 
            self.score += 1  # Increase score
            self.CreateFood()  # Generate new food at a random position
        else:
            self.snake.pop()  # Remove tail if the snake didn't eat food (snake only grows if it eats food)

        # Check for collisions with walls or itself
        if not (0 <= HeadX < BHEIGHT and 0 <= HeadY < BWIDTH) or NewHead in self.snake[1:]:
            self.game_over = True  # Set game over if the snake hits the wall or itself


#This method:
#Calculates the new head position based on the current direction.
#Inserts new_head at the start of self.snake to simulate the snake moving forward.
#Checks if the new head position matches the food position:
#If true, increases score and generates new food.
#If false, removes the last part of the snake (self.snake.pop()), so the snake’s length remains the
#same unless it eats.
#Checks for collisions:Ends the game if the snake hits the wall or itself.

#0 <= HeadX < BHEIGHT and 0 <= HeadY < BWIDTH:
#This part checks if the snake's head (HeadX, HeadY) is within the bounds of the game area.
#HeadX is the x-coordinate (horizontal position) of the snake's head, and HeadY is the
#y-coordinate (vertical position).BHEIGHT and BWIDTH are the dimensions of the game area 
#(height and width).This condition ensures that the snake's head is within the valid playable area,
#i.e., HeadX should be between 0 and BHEIGHT - 1, and HeadY should be between 0 and BWIDTH - 1.

#not (0 <= HeadX < BHEIGHT and 0 <= HeadY < BWIDTH):
#This negates the previous condition. If the snake's head goes outside the boundaries of the game area, 
#this part will evaluate to True.

#NewHead in self.snake[1:]:
#This checks if the new position of the snake's head (NewHead) already occupies a part of the 
#snake's body.self.snake likely represents a list of coordinates for all parts of the snake's body, 
#with the head at index 0 and the rest of the body at indices 1: (from index 1 onward).
#If NewHead is found in self.snake[1:], it means the snake's head has collided with its own body.

#or:
#The or operator means that if either the snake's head is out of bounds or it collides with its own body,
#the game should end.

#self.game_over = True:
#If either of the conditions is true (head out of bounds or collision with the body), the game is
#marked as over by setting self.game_over to True

    def change_direction(self, new_direction): 
    #This method is used to change the direction of the snake based on the player’s input 
    #within SnakeGame class.or we can say Change direction if it's valid
    
        """Change the snake's direction, avoiding direct reversals"""
        # Update direction if it doesn't directly reverse the current direction
        if (self.direction == UP and new_direction != DOWN) or \
           (self.direction == DOWN and new_direction != UP) or \
           (self.direction == LEFT and new_direction != RIGHT) or \
           (self.direction == RIGHT and new_direction != LEFT):
            self.direction = new_direction
            
#This method changes the snake’s direction based on player input, preventing reversal to avoid
#immediate self-collision.

#if (self.direction == UP and new_direction != DOWN) #Checks if the snake is moving UP, and it ensures
#that the new direction is not DOWN as that would cause an immediate collision with itself.

#(self.direction == DOWN and new_direction != UP) #Checks if the snake is moving DOWN, and it ensures
#that the new direction is not UP as that would cause an immediate collision with itself.

#(self.direction == LEFT and new_direction != RIGHT) Checks if the snake is moving LEFT and ensures 
#that the new direction is not RIGHT as that would cause an immediate collision with itself.

#self.direction == RIGHT and new_direction != LEFT):  #Checks if the snake is moving RIGHT and prevents
#the snake from changing direction to LEFT as that would cause an immediate collision with itself.

#self.direction = new_direction #This line effectively changes the direction in which the snake will
#move in the next iteration of the game loop.

    def DrawBorder(self):
        """DrawBorder the game screen and display the score"""

        # Print the top border
        print("^" + "-" * BWIDTH + "^")

        # Print each row of the game board
        for row in range(BHEIGHT): # This line starts a for loop that iterates through each row 
        #of the game screen.
        
            line = "|" #This initializes a string line with the first character as "|", 
            #which represents the left border of the game screen.
            
            for col in range(BWIDTH): #This starts another for loop, which iterates over each
            #column in the current row.
            
                if (row, col) in self.snake: #This line checks if the current (row, col) position is part of
                #the snake's body.
                
                    line += S_CHAR # Display snake character if part of the snake
                    #If the condition is true (i.e., the current (row, col) position is part of 
                    #the snake), this line adds the snake character (S_CHAR, which is *) to the
                    #line string.
                    
                elif (row, col) == self.food: ##This line checks if the current (row, col) 
                #position is where the food is located.
                
                    line += FOOD_CHAR  # Display food character if food is at this position
                    #If the condition is true (i.e., the current (row, col) position is the food),
                    #this line adds the food character (FOOD_CHAR, which is O) to the line string.
                else:
                    line += EMPTY # Display empty character otherwise
                    #If the current position is empty (i.e., it is not part of the snake and not the food), 
                    #this line appends the empty character (.) to the line string
                    
            line += "|"
            #After the loop over all columns for the current row is finished, this line adds the right border (|) 
            #to the line string.
            
            print(line)#Each row of the game board is printed one by one in the loop.

        # Print the bottom border
        print("^" + "-" * BWIDTH+ "^")

        # Print the current score
        print("Score: {}".format(self.score))

#The draw method:

#Prints the top border. For each row, constructs a string with symbols for each cell:
#Snake segments (S_CHAR), food (FOOD_CHAR), or empty space (EMPTY).
#Prints the bottom border and the current score.

    def play(self): #This defines the play method, which is responsible for running the main game loop
        """Run the game loop"""
        while not self.game_over:#This line starts the main game loop, which continues running as long as
        #the game is not over.
        
            self.DrawBorder()  # Display the game board
            #This method will render and print the current state of the game (the game board, the snake,
            #the food, and the score) to the console. It will be called at the start of each loop 
            #iteration to visually update the game screen.

            # Get user input for movement direction
            move = input("Enter your move (W for 'UP' A For 'LEFT' S FOR 'DOWN' D FOR 'RIGHT'): ").strip().upper()

            # Update direction based on user input
            if move == "W":
                self.change_direction(UP)
            elif move == "A":
                self.change_direction(LEFT)
            elif move == "S":
                self.change_direction(DOWN)
            elif move == "D":
                self.change_direction(RIGHT)

            # Move the snake in the current direction
            self.move()#This line calls the move method to update the snake’s position 
            #based on its current direction.

#The play method is the game loop:
#Continuously draws the game screen and waits for player input.
#Based on input (W, A, S, D), it changes direction or keeps the current direction.
#Moves the snake according to self.move().
#Ends the loop if self.game_over is set to True.

#If the snake eats food, it grows longer, and if it collides with a wall or itself, 
#the game ends (setting self.game_over = True).

        # Display game over message and final score
        
        print("\nGame Over! Thank you for playing") #If the game loop exits (because self.game_over became True),
        #this line prints the message "Game Over! thank you for playing" to the screen, notifying the player 
        #that the game has ended.
        
        print("Congratulations! Your final score is: {}".format(self.score))
        #This line prints the final score to the screen using the self.score value.

'''
It imports the snakegame classes into the main program to run 
This block creates an instance of SnakeGame and starts the game when the script is executed.
'''
#from snakegame import *

# Main function to start the game
if __name__ == "__main__":    #This condition ensures that the code block inside it only runs when the script
    #is executed directly, and not when it is imported
    
    game = SnakeGame()  # Create a SnakeGame instance
    #This line creates an instance of the SnakeGame class and assigns it to the variable game.
    
    game.play()  # Start the game
    #This line starts the game by calling the play method on the game object, 
    #which is an instance of the SnakeGame class.


